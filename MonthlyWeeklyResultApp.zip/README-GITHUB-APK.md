# Build the APK on GitHub — no Android Studio required

1. Create a GitHub repository.
2. Upload all files/folders from this project into the repository root.
3. Open **Actions** → **Build Android APK**.
4. Click **Run workflow** (or push to `main`/`master`).
5. Wait for the build to finish.
6. Open the completed workflow run and scroll to **Artifacts**.
7. Download `MonthlyWeeklyResult-debug-apk` and extract `app-debug.apk`.

The workflow uses JDK 17, Android SDK 36, Build Tools 35.0.0 and Gradle 8.13. AGP 8.13 requires Gradle 8.13 and JDK 17.
