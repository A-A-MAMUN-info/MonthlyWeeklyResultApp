# Monthly Weekly Result — Android App Project

This project is a first working-version blueprint based on the supplied `Class .... 10.xlsx` workflow.

## Workflow
- Add students once (ID + Name)
- Create each weekly subject exam for a month (Week 1–5, subject, date, full mark)
- Enter marks student-by-student
- Monthly result automatically combines only the exams created for that month
- Rank is calculated from monthly percentage
- Individual student report shows weekly subjects, total, average %, grade and position

## Excel mapping
The supplied workbook has `Marks` and `Report` sheets. The app keeps the same basic idea: a marks-entry area and a student-specific report, but stores data locally in SQLite instead of spreadsheet formulas.

## Build
Open this folder in Android Studio (current stable). Let Android Studio install/sync the required Android SDK and Gradle components, then choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

Minimum Android version: 6.0 (API 23). Target SDK: 36.

## Current limitations in v1
- No Excel import/export yet.
- No PDF printing yet.
- No cloud backup yet.
- Subject/full-mark rules are entered per weekly exam so the monthly sheet can contain 4 or 5 subjects exactly as needed.
