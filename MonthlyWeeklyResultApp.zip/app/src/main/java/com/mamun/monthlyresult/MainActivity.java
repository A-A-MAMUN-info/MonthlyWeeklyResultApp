package com.mamun.monthlyresult;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, content;
    TextView title;
    int blue=Color.rgb(23,105,170), dark=Color.rgb(13,79,128), light=Color.rgb(242,247,251);
    String selectedMonth="";
    final String[] subjects={"BAN-1","BAN-2","ENG-1","ENG-2","MATH","H.M/H.S","PHYSICS","CHEMISTRY","BIOLOGY","BGS","RELIGION","ICT"};

    @Override public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); showHome();}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView tv(String s,float size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.DKGRAY);t.setPadding(dp(12),dp(8),dp(12),dp(8));if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setSingleLine(true);e.setPadding(dp(12),dp(4),dp(12),dp(4));return e;}
    void base(String name){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(light);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(8),dp(4),dp(8),dp(4));bar.setBackgroundColor(blue);
        title=tv(name,20,true);title.setTextColor(Color.WHITE);bar.addView(title,new LinearLayout.LayoutParams(0,dp(56),1));
        root.addView(bar);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(12),dp(12),dp(24));
        ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    void showHome(){
        base("Monthly Weekly Result");
        content.addView(tv("Monthly Weekly Examination",26,true));
        content.addView(tv("Excel-style monthly result system • 4/5 weekly subjects",14,false));
        Button students=btn("👨‍🎓  Students"); Button exams=btn("📝  Weekly Exam / Marks Entry"); Button results=btn("📊  Monthly Result"); Button report=btn("📄  Student Report");
        for(Button b:new Button[]{students,exams,results,report}){content.addView(b,new LinearLayout.LayoutParams(-1,dp(54)));}
        students.setOnClickListener(v->showStudents()); exams.setOnClickListener(v->showExams()); results.setOnClickListener(v->showMonthlyResult()); report.setOnClickListener(v->showReport());
        content.addView(tv("Workflow",18,true));content.addView(tv("1. Add students\n2. Create each week's subject exam\n3. Enter marks\n4. Monthly total + average + position are calculated automatically\n5. Open a student to see the individual report",15,false));
    }
    void showStudents(){
        base("Students");
        Button add=btn("＋ Add Student");content.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));add.setOnClickListener(v->studentDialog(null));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,student_id,name FROM students ORDER BY CAST(student_id AS INTEGER), student_id",null);
        while(c.moveToNext()){final long rid=c.getLong(0);LinearLayout row=new LinearLayout(this);row.setPadding(0,dp(3),0,dp(3));TextView x=tv(c.getString(1)+"  •  "+c.getString(2),16,false);row.addView(x,new LinearLayout.LayoutParams(0,dp(52),1));Button ed=btn("Edit");row.addView(ed,new LinearLayout.LayoutParams(dp(80),dp(52)));content.addView(row);ed.setOnClickListener(v->studentDialog(rid));}
        c.close();
        Button back=btn("← Back");content.addView(back);back.setOnClickListener(v->showHome());
    }
    void studentDialog(Long rowId){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(10),0,dp(10),0);
        EditText id=edit("Student ID");EditText name=edit("Student Name");box.addView(id);box.addView(name);
        if(rowId!=null){Cursor c=db.getReadableDatabase().rawQuery("SELECT student_id,name FROM students WHERE id=?",new String[]{""+rowId});if(c.moveToFirst()){id.setText(c.getString(0));name.setText(c.getString(1));}c.close();}
        AlertDialog d=new AlertDialog.Builder(this).setTitle(rowId==null?"Add Student":"Edit Student").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{if(id.getText().toString().trim().isEmpty()||name.getText().toString().trim().isEmpty()){Toast.makeText(this,"ID and Name are required",Toast.LENGTH_SHORT).show();return;}if(rowId==null)db.addStudent(id.getText().toString().trim(),name.getText().toString().trim());else db.editStudent(rowId,id.getText().toString().trim(),name.getText().toString().trim());d.dismiss();showStudents();}));d.show();
    }
    void showExams(){
        base("Weekly Exams / Marks");
        Button add=btn("＋ Create Weekly Subject Exam");content.addView(add,new LinearLayout.LayoutParams(-1,dp(54)));add.setOnClickListener(v->examDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,month,week,subject,exam_date,full_mark FROM exams ORDER BY id DESC",null);
        while(c.moveToNext()){final long eid=c.getLong(0);String s=c.getString(1)+" • Week "+c.getInt(2)+" • "+c.getString(3)+"\nDate: "+c.getString(4)+" • Full Mark: "+c.getInt(5);Button b=btn(s+"\nEnter / Edit Marks");b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);content.addView(b,new LinearLayout.LayoutParams(-1,dp(72)));b.setOnClickListener(v->marksEntry(eid));}
        c.close();Button back=btn("← Back");content.addView(back);back.setOnClickListener(v->showHome());
    }
    void examDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(10),0,dp(10),0);
        EditText month=edit("Month & Year (e.g. September 2026)");EditText week=edit("Week (1-5)");week.setInputType(InputType.TYPE_CLASS_NUMBER);EditText date=edit("Exam Date (e.g. 05-09-2026)");EditText full=edit("Full Mark (e.g. 100)");full.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);Spinner sp=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,subjects);sp.setAdapter(a);
        box.addView(month);box.addView(week);box.addView(sp);box.addView(date);box.addView(full);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Create Weekly Exam").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Create",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{try{int w=Integer.parseInt(week.getText().toString());double fm=Double.parseDouble(full.getText().toString());if(month.getText().toString().trim().isEmpty()||w<1||w>5||fm<=0)throw new Exception();db.addExam(month.getText().toString().trim(),w,subjects[sp.getSelectedItemPosition()],date.getText().toString().trim(),fm);d.dismiss();showExams();}catch(Exception e){Toast.makeText(this,"Enter valid month, week 1-5 and full mark",Toast.LENGTH_SHORT).show();}}));d.show();
    }
    void marksEntry(long eid){
        Cursor ec=db.getReadableDatabase().rawQuery("SELECT month,week,subject,exam_date,full_mark FROM exams WHERE id=?",new String[]{""+eid});if(!ec.moveToFirst()){ec.close();return;}String head=ec.getString(0)+" • Week "+ec.getInt(1)+" • "+ec.getString(2);double full=ec.getDouble(4);ec.close();
        base("Marks Entry");content.addView(tv(head,20,true));content.addView(tv("Exam Date: "+db.examDate(eid)+"   |   Full Mark: "+full,14,false));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,student_id,name FROM students ORDER BY CAST(student_id AS INTEGER),student_id",null);ArrayList<EditText> fields=new ArrayList<>();ArrayList<Long> ids=new ArrayList<>();
        while(c.moveToNext()){long sid=c.getLong(0);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView n=tv(c.getString(1)+"  "+c.getString(2),14,false);row.addView(n,new LinearLayout.LayoutParams(0,dp(58),1));EditText m=edit("Marks");m.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);String old=db.mark(eid,sid);if(!old.isEmpty())m.setText(old);row.addView(m,new LinearLayout.LayoutParams(dp(110),dp(58)));content.addView(row);fields.add(m);ids.add(sid);}
        c.close();Button save=btn("💾 Save Marks");content.addView(save,new LinearLayout.LayoutParams(-1,dp(54)));save.setOnClickListener(v->{for(int i=0;i<fields.size();i++){String val=fields.get(i).getText().toString().trim();if(val.isEmpty())db.deleteMark(eid,ids.get(i));else{try{double x=Double.parseDouble(val);if(x<0||x>full){Toast.makeText(this,"Marks cannot exceed full mark",Toast.LENGTH_SHORT).show();return;}db.saveMark(eid,ids.get(i),x);}catch(Exception ex){Toast.makeText(this,"Invalid mark",Toast.LENGTH_SHORT).show();return;}}}Toast.makeText(this,"Marks saved",Toast.LENGTH_SHORT).show();showExams();});
        Button back=btn("← Back");content.addView(back);back.setOnClickListener(v->showExams());
    }
    void showMonthlyResult(){
        base("Monthly Result");
        Spinner ms=new Spinner(this);ArrayList<String> months=db.months();if(months.isEmpty())months.add("No month yet");ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,months);ms.setAdapter(a);content.addView(tv("Select Month",16,true));content.addView(ms);Button view=btn("View Monthly Result");content.addView(view,new LinearLayout.LayoutParams(-1,dp(52)));LinearLayout table=new LinearLayout(this);table.setOrientation(LinearLayout.VERTICAL);content.addView(table);view.setOnClickListener(v->renderMonthly(table,ms.getSelectedItem().toString()));Button back=btn("← Back");content.addView(back);back.setOnClickListener(v->showHome());if(!months.isEmpty()&&!months.get(0).equals("No month yet"))renderMonthly(table,months.get(0));
    }
    void renderMonthly(LinearLayout table,String month){table.removeAllViews();Cursor c=db.getReadableDatabase().rawQuery("SELECT id,student_id,name FROM students ORDER BY CAST(student_id AS INTEGER),student_id",null);ArrayList<StudentScore> list=new ArrayList<>();while(c.moveToNext()){StudentScore s=new StudentScore();s.id=c.getLong(0);s.sid=c.getString(1);s.name=c.getString(2);double[] q=db.monthScore(month,s.id);s.total=q[0];s.full=q[1];s.avg=s.full==0?0:s.total/s.full*100;list.add(s);}c.close();Collections.sort(list,(x,y)->Double.compare(y.total/x.fullSafe(),x.total/x.fullSafe()));
        int rank=1;double prev=-1;for(int i=0;i<list.size();i++){StudentScore s=list.get(i);if(prev>=0&&Math.abs(s.percent()-prev)>0.0001)rank=i+1;s.rank=rank;prev=s.percent();}
        table.addView(tv("Month: "+month,20,true));table.addView(tv("ID        Student                         Total / Full        Avg%     Position",13,true));for(StudentScore s:list){table.addView(tv(String.format(Locale.US,"%-8s %-30s %7.0f/%-7.0f %7.2f   %d",s.sid,trim(s.name,28),s.total,s.full,s.percent(),s.rank),13,false));}
    }
    String trim(String s,int n){return s.length()>n?s.substring(0,n-1)+"…":s;}
    void showReport(){
        base("Student Report");EditText id=edit("Enter Student ID");content.addView(id);Spinner ms=new Spinner(this);ArrayList<String> months=db.months();if(months.isEmpty())months.add("No month yet");ms.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,months));content.addView(ms);Button b=btn("Show Report");content.addView(b,new LinearLayout.LayoutParams(-1,dp(52)));LinearLayout out=new LinearLayout(this);out.setOrientation(LinearLayout.VERTICAL);content.addView(out);b.setOnClickListener(v->renderReport(out,id.getText().toString().trim(),ms.getSelectedItem().toString()));Button back=btn("← Back");content.addView(back);back.setOnClickListener(v->showHome());
    }
    void renderReport(LinearLayout out,String sid,String month){out.removeAllViews();Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM students WHERE student_id=?",new String[]{sid});if(!c.moveToFirst()){c.close();out.addView(tv("Student not found",16,true));return;}long st=c.getLong(0);String name=c.getString(1);c.close();out.addView(tv("MONTHLY WEEKLY EXAM RESULT",22,true));out.addView(tv(month,17,false));out.addView(tv("Student ID: "+sid+"\nName: "+name,16,true));Cursor e=db.getReadableDatabase().rawQuery("SELECT id,week,subject,exam_date,full_mark FROM exams WHERE month=? ORDER BY week,id",new String[]{month});double total=0,full=0;while(e.moveToNext()){long eid=e.getLong(0);String m=db.mark(eid,st);if(m.isEmpty())continue;double mark=Double.parseDouble(m);double fm=e.getDouble(4);total+=mark;full+=fm;out.addView(tv(String.format(Locale.US,"Week %d • %-12s  %s/%s  • %s",e.getInt(1),e.getString(2),m,e.getString(4),e.getString(3)),15,false));}e.close();double pct=full==0?0:total/full*100;int rank=db.rank(month,st);out.addView(tv(String.format(Locale.US,"\nTotal: %.0f / %.0f\nAverage: %.2f%%\nGrade: %s\nPosition: %d",total,full,pct,grade(pct),rank),18,true));}
    String grade(double p){if(p>=80)return "A+";if(p>=70)return "A";if(p>=60)return "A-";if(p>=50)return "B";if(p>=40)return "C";if(p>=33)return "D";return "F";}

    static class StudentScore{long id;String sid,name;double total,full,avg;int rank;double percent(){return full==0?0:total/full*100;}double fullSafe(){return full==0?1:full;}}

    class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"monthly_result.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id TEXT UNIQUE,name TEXT NOT NULL)");d.execSQL("CREATE TABLE exams(id INTEGER PRIMARY KEY AUTOINCREMENT,month TEXT,week INTEGER,subject TEXT,exam_date TEXT,full_mark REAL)");d.execSQL("CREATE TABLE marks(id INTEGER PRIMARY KEY AUTOINCREMENT,exam_id INTEGER,student_id INTEGER,mark REAL,UNIQUE(exam_id,student_id))");}
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        void addStudent(String id,String n){getWritableDatabase().execSQL("INSERT OR REPLACE INTO students(student_id,name) VALUES(?,?)",new Object[]{id,n});}
        void editStudent(long id,String sid,String n){getWritableDatabase().execSQL("UPDATE students SET student_id=?,name=? WHERE id=?",new Object[]{sid,n,id});}
        void addExam(String m,int w,String s,String date,double f){getWritableDatabase().execSQL("INSERT INTO exams(month,week,subject,exam_date,full_mark) VALUES(?,?,?,?,?)",new Object[]{m,w,s,date,f});}
        String examDate(long id){Cursor c=getReadableDatabase().rawQuery("SELECT exam_date FROM exams WHERE id=?",new String[]{""+id});String x="";if(c.moveToFirst())x=c.getString(0);c.close();return x;}
        String mark(long eid,long sid){Cursor c=getReadableDatabase().rawQuery("SELECT mark FROM marks WHERE exam_id=? AND student_id=?",new String[]{""+eid,""+sid});String x="";if(c.moveToFirst())x=String.valueOf(c.getDouble(0));c.close();return x;}
        void saveMark(long eid,long sid,double m){getWritableDatabase().execSQL("INSERT OR REPLACE INTO marks(exam_id,student_id,mark) VALUES(?,?,?)",new Object[]{eid,sid,m});}
        void deleteMark(long eid,long sid){getWritableDatabase().execSQL("DELETE FROM marks WHERE exam_id=? AND student_id=?",new Object[]{eid,sid});}
        ArrayList<String> months(){ArrayList<String>a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT DISTINCT month FROM exams WHERE month IS NOT NULL AND month<>'' ORDER BY id DESC",null);while(c.moveToNext())a.add(c.getString(0));c.close();return a;}
        double[] monthScore(String month,long sid){Cursor c=getReadableDatabase().rawQuery("SELECT m.mark,e.full_mark FROM marks m JOIN exams e ON e.id=m.exam_id WHERE e.month=? AND m.student_id=?",new String[]{month,""+sid});double t=0,f=0;while(c.moveToNext()){t+=c.getDouble(0);f+=c.getDouble(1);}c.close();return new double[]{t,f};}
        int rank(String month,long sid){Cursor c=getReadableDatabase().rawQuery("SELECT id FROM students",null);ArrayList<Double> ps=new ArrayList<>();long target=0;while(c.moveToNext()){long id=c.getLong(0);if(id==sid)target=id;double[]q=monthScore(month,id);ps.add(q[1]==0?0:q[0]/q[1]*100);}c.close();double[] q=monthScore(month,target);double p=q[1]==0?0:q[0]/q[1]*100;int r=1;for(double x:ps)if(x>p+0.0001)r++;return r;}
    }
}
